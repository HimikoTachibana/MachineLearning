Responses to Question 5

5.1 Run Q5pt1.py for responses

1. The country with the highest child mortality rate
in 1990 is Liberia with rate 160.8

2. The country with the highest child mortality rate
in 2011 is Sierra Leonne with rate 119.2

3. The API takes care of the NaN values by initializing them to unknown values

5.2 

1. The testing error is higher than the training error

2. 
